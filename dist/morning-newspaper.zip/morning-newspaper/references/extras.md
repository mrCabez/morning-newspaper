# Extras

Two boxes at the end of the edition, written in the reader's language. Both are short (up to 2 sentences) and must be true: confirm before using, never write from memory alone.

## On this day
- Something that happened on this date (day and month) in a past year.
- Prefer, in order: technology and computing, the reader's country and region, science, culture.
- Format: "In [year], [what happened]." plus, if it fits, one sentence on why it matters.
- The collection already brings Wikipedia candidates (`h1`, `h2`…), ranked by `history_keywords` and without anything on the reader's `avoid` list; Wikipedia counts as confirmation. Rewrite the fact in your own words.
- Only if there are no candidates: search "[day month] in history" (in the reader's language) and confirm the year in a second source if unclear.
- Tie-breaker only: between two equally good candidates, prefer the one that is not about a war, tragedy or death. Never discard a candidate for that alone; what the reader does not want to see is in their `avoid` list, and the collection already applied it.
- Collected text is flattened: exponents and formulas lose their formatting (2^1398269 − 1 can arrive as "21398269−1"). Check numbers like these on the linked page, or leave them out.

## Did you know?
- First choice: the collection's candidates (`k1`, `k2`…, Wikipedia articles on today's theme, sometimes from the English Wikipedia: write the fact in the reader's language). Their text counts as confirmation: use `{"ref": "k1", "text": "…"}` and no search is needed. This section is for when none fits or none came (no network, Wikipedia down).
- Follow **today's theme**, printed by the collection (`[did_you_know] today's theme`). It rotates daily so the box stays varied. If the theme leaves no fresh fact (the facts it suggests are already used, or none is confirmed), widen it to any lesser-known fact about technology or science, never a default favorite.
- Pick a lesser-known fact inside that theme. **Never use these overused classics:** the moth in the Harvard Mark II as the "first bug"; Ada Lovelace as the first programmer; QWERTY designed to slow typists; the first email or the first website; "640K ought to be enough"; the first computer mouse being made of wood; the Apollo guidance computer being weaker than a calculator or phone; the origin of the word "spam".
- Do not repeat: the collection lists the ones already used (compare the subject, not just the wording).
- Confirm it with a web search (at most two) and open a confirming page (fetch it) **from those results**: search result titles and the search tool's own summary do not confirm a fact, and a page whose address you made up yourself is not a result. A page does not open: try the next result that states the fact, up to three pages in all. Put the URL of the page that confirmed it in `did_you_know.url`.
- Light, almanac-like tone, no exaggeration.

## When it does not work out
If a search does not confirm a fact, pick another (still within two searches and three pages). If nothing is confirmed, the box is left out; the other box then takes the full width by itself.
