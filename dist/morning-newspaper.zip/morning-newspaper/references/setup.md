# First-run setup

Run this only in an interactive session, when there is no newsstand or it has no `config.json`, or when the reader asks to change their newspaper. Speak in the language the user is writing in.

## 1. Check the connections first (before any question)

The agenda comes from Google Calendar and the emails waiting for a reply from Gmail. Check whether their tools are available in this session.
- If one is missing, search the connector registry for it and suggest it right away, so the connect button appears before the questions. One sentence is enough: without Calendar there is no agenda; without Gmail there are no emails waiting for a reply.
- Do not wait for the reader to connect: continue with the questions. Whatever gets connected is used from the first edition on.

## 2. Ask (clickable choices when available)

Ask with the session's multiple-choice question tool when there is one (e.g. `AskUserQuestion`): the reader clicks instead of typing, which is what keeps the personalized setup at about a minute. Without such a tool, ask the same questions in **one** message with numbered options, ending with an example of a short reply (e.g. "Reply like: 1 · 1, 2, 4 · 7:00 · nothing"). Write everything in the reader's language.

Rules for every question:
- Every option is a real choice. Never add an option that only means "I'll type it": the tool already has its own free-text field (its label changes between apps, so never name it). When free text makes sense, add "(you can also write your own)" to the question.
- Put the default first and mark it "(Recommended)". A skipped question means its default.
- At most 4 options per question.

**Screen 1** (one question): "How do you want to start?"
- **Personalize (Recommended)**: "About 1 minute: topics, delivery time and subjects you would rather not see."
- **Quick start**: "Just tell me your city. Everything else uses the defaults and can be changed later."

**Screen 2** (only for Personalize; one call, three questions):
1. **Topics** (multi-select; "you can pick several or write others"): the four default sections, each with a one-line description: technology/AI/security, news from your city, personal finance, games. Topics the reader writes become extra sections.
2. **Delivery time**: "7:00 (Recommended)", "6:00", "Another time" and "Don't schedule for now". "Another time" → ask for the time in one short line of text.
3. **Subjects you would rather not see** (multi-select; "you can pick several or write others"): "Nothing, show me everything" (default), "Politics", "Crime and tragedies" and the most followed sport in the reader's country (e.g. "Football"). If "Nothing" is picked together with a subject, the subjects win.

**Then one line of text** (both paths): the city for the weather and local news (required) and what the newspaper should call them (optional), plus the privacy line, e.g.: "Your answers are saved only in your private newsstand; nothing is sent or shared." If the city is already clear from the conversation, ask to confirm it instead.

The newspaper's name is not asked: it uses the default for the language (`default_newspaper_name` in `assets/i18n/`). Readers who want another name can ask for it at any time; it is a one-line change to `newspaper.name`.

If the reader answers screen 1 only with a city, treat it as the quick start.

## 3. Build config.json

Start from `references/config.example.json` and fill in:
- `language`: BCP-47 tag (e.g. `pt-BR`, `es`, `en-GB`). `timezone`: IANA name for their city.
- `reader.name` (may be empty), `newspaper.name` (leave it out: the default for the language is used), `newspaper.motto` (a short retro motto in their language). `newspaper.editor` only if the assistant writing the paper is not Claude: its name for the footer credit, or `""` to leave the credit out.
- `city`: name as used in the news, plus latitude and longitude, confirmed with one web search (never from memory), and `country` (ISO code, e.g. `BR`, `PT`, `US`). Confirm the state or region with the reader when the name is shared by other places.
- `region`: leave it out (or `{"radius_km": 60}` when the reader wants a wider or narrower region). The first collection builds the list of nearby towns, villages and districts by itself (Brazil: IBGE; elsewhere: GeoNames) and `assemble.py` publishes it; never write that list yourself unless `collect.py` prints `REGION:` saying no source answered.
- `news_locale`: Google News parameters for their country and language (`hl`, `gl`, `ceid`), e.g. Brazil `pt-BR` / `BR` / `BR:pt-419`; Spain `es` / `ES` / `ES:es`; US `en-US` / `US` / `US:en`.
- `wikipedia_lang`: their Wikipedia language code (`pt`, `es`, `en`, …).
- `sections`: quick start → the four default sections, with `title` and `queries` translated into their language and the `local` section pointed at their city. Personalized → for each topic an `id` (short, lowercase), a `title` in their language, a `layout` (`main` for the widest section, usually the first; `half` for two short sections shown side by side; `single` for a full-width short section), an `interest` sentence, `count` per weekday/weekend, 2–5 search `queries` in their language (short, no dates, specific enough to stay on topic: "falha de segurança" alone also brings flights and lawsuits, "vulnerabilidade software" does not) and optional RSS `feeds` (https only). Put the country or region in the local and finance queries (e.g. "Valencia", "Comunitat Valenciana", "España inflación"): Google News mixes in other countries that share the language otherwise. **Every local query carries the state or region** (e.g. "Rio Grande da Serra SP", never `"Rio Grande da Serra"` alone): a town whose name contains another place's name (here the states of Rio Grande do Sul and do Norte) otherwise brings that place's news. One query may name the town's region instead, so small towns still get stories.
- `history_keywords`: 10–20 words in their language for preferred "On this day" topics.
- `avoid` (optional): words or short phrases the reader does not want to see, in their language. Only what the reader asked for: leave it `[]` in the quick start, when they picked "Nothing" or skipped, and never fill it in on your own. A subject picked from the list ("Politics") becomes at most 5 obvious words for it, singular and plural included (e.g. "politics", "election", "elections", "party", "government"), shown to the reader in the final summary so they can change them; words the reader wrote go in as written. It applies to every news section and to "On this day", matching whole words only ("war" does not hide "software"), ignoring case and accents; include the variants that matter (singular and plural). A section may also carry its own `avoid` list.
- `keywords` (per section, except the local one): 6–12 short words or phrases in the reader's language that a story of that section carries when it fits the `interest` (a genre, a subject, the proper names of its field: "simulação", "simulador", "sandbox", "city builder", "Minecraft"). Stories that carry one come first in the collection; the others get `fit?`, so a weak list only reorders, it never hides a story. Write them yourself in both paths, without asking: the reader does not need to know the word. In the personalized setup, show them next to each topic as a suggestion; in the quick start, only say in the final summary that each section got words that help pick its stories and can be changed on request. Leave them out for local news (the city already narrows it). Later editions may adjust them on their own, within limits (SKILL.md, step 4).
- `avoid_outlets` (optional): outlet names whose stories never come in, as the collection prints them (e.g. sites of another country that share the language). Leave it `[]` at setup; add names when the reader asks, or when a scheduled run keeps getting another country's outlets.
- `did_you_know_themes` (optional): 20–40 short themes for "Did you know?" tied to their interests. Leave it out to use the built-in technology themes.
- `labels`: leave `{}` if `assets/i18n/` has their language (en, pt-BR, es). Otherwise translate every key of `assets/i18n/en.json` (keep the `{placeholders}` and the 7 weekdays / 12 months order).

Never put emails, phone numbers, addresses or anything sensitive in the config. It holds only what the newspaper needs.

## 4. Save it and print the first edition

The config lives in the reader's newsstand, next to the editions. Run the edition flow from step 2 of SKILL.md with `WORK/config.json`; `assemble.py` adds `config.json` to the files to publish when the newsstand is new. If a newsstand already exists from sample editions (no `config.json`), keep it: run `assemble.py` with `--index` and `--with-config`; numbering simply continues. To change the config of an existing newsstand, rerun `assemble.py` with `--with-config` (or publish just `config.json` in patch mode).

After the edition, reply in their language with a short summary:
- today's headline;
- what was configured (city and topics), said as settings ("topics: …"), never as what today's edition contains: the edition carries only what the `COVERAGE:` line of `assemble.py` says;
- one **Missing** line when `COVERAGE:` lists empty sections (as in SKILL.md step 8);
- only if `avoid` is not empty: the words being avoided, asking whether to remove or add any;
- which connections are still missing (if any) and the newsstand slug (single page: the artifact, and the sentence from SKILL.md step 8);
- direct feeds: run `python3 SKILL/scripts/feeds.py --config WORK/config.json --collected WORK/collected.json` after the first edition. When it prints `FEED:` lines, one line asking whether to add those outlets' own feeds (they bring stories with a summary); name the sections, not the URLs. On a yes, run it again with `--write` and publish `config.json` (patch mode). The same applies whenever the reader asks for better or more local sources.

Then the schedule:
- **A time was chosen** (7:00, 6:00 or another time): create the daily schedule now (`references/scheduling.md`) and say so in the summary.
- **"Don't schedule for now", the quick start, or the question was skipped:** create nothing. Only if this session has a scheduled-task tool, end with one line telling them they can ask at any time, e.g.: "Whenever you want it every morning, just send me 'schedule my newspaper'."
- **No scheduled-task tool in this session:** skip the delivery-time question in screen 2 (there is nothing to schedule) and create nothing.
